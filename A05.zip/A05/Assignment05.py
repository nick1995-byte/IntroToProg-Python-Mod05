# ------------------------------------------------------------------------------------------ #
# Title: Assignment05
# Desc: This assignment demonstrates using dictionaries, files, and exception handling
# Change Log: (Nick Tehrani, 7/27/2024, Created Script)
# ------------------------------------------------------------------------------------------ #

import json
# Define the Data Constants
MENU: str = '''
---- Course Registration Program ----
  Select from the following menu:  
    1. Register a Student for a Course.
    2. Show current data.  
    3. Save data to a file.
    4. Exit the program.
----------------------------------------- 
'''
FILE_NAME: str = "Enrollments.json"
FILE_NAME_CSV: str = "Enrollments.csv"

# Define the Data Variables
student_first_name: str = ''  # Holds the first name of a student entered by the user.
student_last_name: str = ''  # Holds the last name of a student entered by the user.
course_name: str = ''  # Holds the name of a course entered by the user.
json_data: str = ''  # Holds data that mirrors data loaded into json file.
file = None  # Holds a reference to an opened file.
menu_choice: str  # Hold the choice made by the user.
student_data: dict = {}  # Holds one row of student data.
students: list = []  # Holds a table of student data.
count: int = 1  # Used to indicate in custom message which row of data has an issue.
csv_data: str = ''  # Holds data that was loaded into csv file.

# When the program starts, read the file data into a list of dictionaries (table)
# Extract the data from the file
file = open(FILE_NAME, "r")
print(f"\n{FILE_NAME} file reading completed")
for item in json.load(file):
    try:
        item["FirstName"]
    except Exception as e:
        print(f"Error: First Name Key is missing for student number {count} in "
              f"the Enrollments.json file")
    try:
        item["LastName"]
    except Exception as e:
        print(f"Error: Last Name Key is missing for student number {count} in the "
              f"Enrollments.json file")
    try:
        item["CourseName"]
    except Exception as e:
        print(f"Error: Course Name Key is missing for student number {count} in the "
              f"Enrollments.json file")
    student_data = item
    # Load it into our collection (list of dictionaries)
    students.append(student_data)
    count += 1
file.close()

# Present and Process the data
while True:

    # Present the menu of choices
    print(MENU)
    menu_choice = input("What would you like to do: ")

    # Input user data
    if menu_choice == "1":  # This will not work if it is an integer!
        while True:
            try:
                # Input the data
                student_first_name = input("\nEnter the student's first name (or type "
                                           "Menu to cancel request): ")
                if not student_first_name.isalpha():
                    raise ValueError("\nError: The first name should not contain "
                                     "numbers.\n")
                else:
                    break
            except ValueError as e:
                print(e)
                continue
            except Exception as e:
                print("There was a non-specific error!\n")
                break
        if student_first_name.lower() == "menu":
            continue

        while True:
            try:
                # Input the data
                student_last_name = input("Enter the student's last name (or type Menu "
                                          "to cancel request): ")
                if not student_last_name.isalpha():
                    raise ValueError("\nError: The last name should not contain numbers."
                                     "\n")
                else:
                    break
            except ValueError as e:
                print(e)
                continue
            except Exception as e:
                print("There was a non-specific error!\n")
                break
        if student_last_name.lower() == "menu":
            continue

        course_name = input("Enter the course name: ")
        student_data = {"FirstName": student_first_name,
                        "LastName": student_last_name,
                        "CourseName": course_name}
        students.append(student_data)
        continue

    # Present the current data
    elif menu_choice == "2":

        # Process the data to create and display a custom message
        print("\n" + "-"*50)
        print("The following students are enrolled in the listed courses."
              "\nif either First Name, Last Name, or Course Name Key is missing,"
              "\nthat data will be highlighted with an error message.\n")
        for student in students:
            if student.get("FirstName") is None:
                student_first_name = "(Error: Missing First Name Key)"
            else:
                student_first_name = student.get("FirstName")
            if student.get("LastName") is None:
                student_last_name = "(Error: Missing Last Name Key)"
            else:
                student_last_name = student.get("LastName")
            if student.get("CourseName") is None:
                course_name = "(Error: Missing Course Name Key)"
            else:
                course_name = student.get("CourseName")
            print(f"Student {student_first_name} {student_last_name} is enrolled in "
                  f"{course_name}")
        print("-"*50)
        continue

    # Save the data to a file
    elif menu_choice == "3":
        file = open(FILE_NAME, "w")
        json.dump(students, file)
        file.close()
        count = 1
        print(f"\nError handling results while writing dictionary rows to the "
              f"{FILE_NAME} file:")
        for student in students:
            try:
                student["FirstName"]
            except Exception as e:
                print(f"Error: First Name Key is missing for student number {count}")
            try:
                student["LastName"]
            except Exception as e:
                print(f"Error: Last Name Key is missing for student number {count}")
            try:
                student["CourseName"]
            except Exception as e:
                print(f"Error: Course Name Key is missing for student number {count}")
            count += 1
            json_data += f"\n {str(student)},"
            csv_data += (
                    (str(student.values()).removeprefix("dict_values([").removesuffix("])").
                        replace("'", "")).replace(" ", "") + "\n")

        json_data = f"[{json_data.rstrip(",")}\n]"
        print(f"\nThe following data was saved to the {FILE_NAME} file!")
        print(json_data)
        file = open(FILE_NAME_CSV, "w")
        file.write(csv_data)
        file.close()
        print(f"\nThe following data was saved to the {FILE_NAME_CSV} file!")
        print(csv_data)
        continue

    # Stop the loop
    elif menu_choice == "4":
        break  # out of the loop
    else:
        print("Please only choose option 1, 2, 3, or 4")

print("Program Ended")
